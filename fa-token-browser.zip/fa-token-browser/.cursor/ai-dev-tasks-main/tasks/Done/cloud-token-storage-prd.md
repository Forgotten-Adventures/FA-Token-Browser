# PRD: Cloud Token Storage with Patreon Authentication

## Executive Summary
Extend the existing Token Browser module to support cloud-based token storage via Cloudflare R2, protected by Patreon subscription authentication. Users can access premium token collections stored in the cloud while maintaining the existing local storage functionality.

## Problem Statement
Currently, the Token Browser only supports local file storage, limiting users to tokens they manually upload. Premium subscribers should have access to curated cloud-based token collections without requiring manual downloads until actually used.

## Goals & Success Metrics

### Primary Goals
- Enable cloud token browsing for Patreon subscribers
- Implement secure, time-limited access control
- Provide seamless integration with existing token browser
- Minimize bandwidth usage through lazy downloading

### Success Metrics
- 99%+ of eligible Patreon subscribers successfully authenticate
- <2 second cloud token metadata loading time
- <2 second token download time on drag & drop
- Zero unauthorized access to premium content

## Target Users
- **Primary**: Patreon subscribers (appropriate tier) using Foundry VTT
- **Secondary**: Free users (existing local functionality unchanged)

## User Stories & Requirements

### Epic 1: Patreon Authentication System
**As a Patreon subscriber**, I want to authenticate my subscription so I can access premium cloud tokens.

#### User Stories:
1. **Authentication Flow**
   - As a user, I can click a "Connect Patreon" button in module settings
   - As a user, I'm redirected to Patreon OAuth with secure state validation
   - As a user, I receive confirmation when authentication succeeds/fails
   - As a user, I can see my current authentication status


#### Technical Requirements:
- OAuth 2.0 flow through n8n webhook system
- Secure token generation with HMAC signature validation
- 30-day access tokens with refresh capability
- Real-time subscription status validation via webhooks
- Local storage of authentication state with expiry tracking

### Epic 2: Cloudflare R2 Integration
**As an authenticated user**, I want to browse cloud-stored tokens seamlessly alongside local tokens.

#### User Stories:
1. **Cloud Token Discovery**
   - As a user, I can see cloud tokens mixed with local tokens in the browser
   - As a user, I can distinguish cloud tokens from local ones visually
   - As a user, I can search/filter cloud tokens using the same interface
   - As a user, I can see loading states while cloud metadata loads

2. **Lazy Token Downloading**
   - As a user, tokens are only downloaded when I drag & drop them
   - As a user, I see download progress during token transfer
   - As a user, downloaded tokens are cached locally for future use
   - As a user, I can clear cached cloud tokens to save disk space

#### Technical Requirements:
- R2 API integration with signed URL generation for private access
- Metadata caching for cloud token listings (filename, size, path structure)
- Progressive loading of token thumbnails with placeholder images
- Local caching system for downloaded tokens with TTL/size limits
- Error handling for network failures and access denials

### Epic 3: Enhanced Token Browser UI
**As a user**, I want the cloud integration to feel native to the existing token browser.

#### User Stories:
1. **Visual Integration**
   - As a user, I can see cloud tokens with a distinctive visual indicator
   - As a user, I can filter between local-only, cloud-only, or all tokens
   - As a user, I can see my current cloud access status in the browser
   - As a user, I can access Patreon authentication from within the token browser

2. **Enhanced Functionality**
   - As a user, I can see download progress when dragging cloud tokens
   - As a user, I can pre-download frequently used tokens
   - As a user, I can see storage usage for cached cloud tokens
   - As a user, I receive helpful error messages for authentication/network issues

#### Technical Requirements:
- Extended search/filter system supporting mixed token sources
- Download progress indicators and caching status display
- Settings panel integration for cloud configuration
- Graceful fallback when cloud services are unavailable

## Technical Architecture

### High-Level Components

```mermaid
graph TB
    TB[Token Browser App] --> LTS[Local Token Scanner]
    TB --> CTS[Cloud Token Service]
    CTS --> R2[R2 Storage Manager]
    CTS --> PA[Patreon Auth Service]
    PA --> N8N[n8n Webhook Handler]
    R2 --> Cache[Local Token Cache]
    
    subgraph "Authentication Flow"
        PA --> OAuth[Patreon OAuth]
        OAuth --> N8N
        N8N --> Webhook{Webhook Response}
        Webhook --> TokenGen[Access Token Generation]
    end
    
    subgraph "Token Loading Flow"
        CTS --> Meta[Metadata Fetch]
        Meta --> Preview[Thumbnail Generation]
        TB --> DragDrop[Drag & Drop Event]
        DragDrop --> Download[Token Download]
        Download --> Cache
    end
```

### Core Services

#### 1. PatreonAuthService
```javascript
class PatreonAuthService {
  // OAuth flow management
  async initiateOAuth(userId)
  async handleCallback(code, state)
  async validateToken(accessToken)
  async refreshToken(refreshToken)
  
  // Access management
  async checkSubscriptionStatus(userId)
  async revokeAccess(userId)
  async getAccessStatus()
}
```

#### 2. R2StorageManager
```javascript
class R2StorageManager {
  // Token discovery
  async scanCloudFolder(folderPath)
  async generateSignedUrl(objectKey, expiryMinutes)
  async getObjectMetadata(objectKey)
  
  // Token operations
  async downloadToken(objectKey, localPath)
  async getThumbnail(objectKey, size)
  async listFolderContents(prefix)
}
```

#### 3. CloudTokenService
```javascript
class CloudTokenService {
  // Integration layer
  async getAvailableTokens()
  async downloadTokenOnDemand(tokenData)
  async cacheToken(tokenData, localPath)
  async getCachedTokens()
  async clearCache(options)
}
```

### Data Models

#### Authentication State
```javascript
{
  userId: string,
  accessToken: string,
  refreshToken: string,
  expiryDate: Date,
  subscriptionTier: string,
  isValid: boolean,
  lastValidated: Date
}
```

#### Cloud Token Metadata
```javascript
{
  id: string,
  filename: string,
  path: string,
  size: number,
  type: 'cloud',
  source: 'r2',
  thumbnailUrl: string,
  downloadUrl: string,
  cached: boolean,
  cachedPath: string,
  lastAccessed: Date
}
```

### Security Considerations

#### Authentication Security
- HMAC-signed state tokens for OAuth flow
- Secure storage of access tokens (encrypted)
- Time-limited access with automatic revocation
- Protection against CSRF and replay attacks

#### R2 Access Security
- Signed URLs with short expiry times (15 minutes)
- IP-based access restrictions where possible
- Rate limiting on token downloads
- Audit logging of all access attempts

#### Data Protection
- No permanent storage of premium content without permission
- Automatic cleanup of expired cached tokens
- Secure transmission of all authentication data
- User consent for data collection/storage

## Implementation Plan

### Phase 1: Authentication Foundation (Sprint 1-2)
- [ ] Implement PatreonAuthService with OAuth flow
- [ ] Create secure token storage system
- [ ] Build webhook handler for subscription status
- [ ] Add authentication UI to module settings
- [ ] Test OAuth flow end-to-end

### Phase 2: R2 Integration (Sprint 3-4)
- [ ] Implement R2StorageManager with basic operations
- [ ] Create signed URL generation system
- [ ] Build metadata caching layer
- [ ] Implement token download functionality
- [ ] Add error handling and retry logic

### Phase 3: Token Browser Integration (Sprint 5-6)
- [ ] Extend token browser to support cloud tokens
- [ ] Add visual indicators for cloud vs local tokens
- [ ] Implement mixed search/filtering
- [ ] Add download progress indicators
- [ ] Create cache management UI

### Phase 4: Polish & Optimization (Sprint 7-8)
- [ ] Implement thumbnail generation/caching
- [ ] Add bulk operations (pre-download, cache clearing)
- [ ] Optimize performance for large token collections
- [ ] Add comprehensive error handling
- [ ] Create user documentation

## Risk Assessment

### High Risk
- **Patreon API changes**: Mitigation - maintain flexible OAuth implementation
- **R2 access costs**: Mitigation - implement aggressive caching and usage monitoring
- **Authentication vulnerabilities**: Mitigation - security audit and penetration testing

### Medium Risk
- **Network dependency**: Mitigation - graceful offline mode and clear user feedback
- **Cache storage bloat**: Mitigation - intelligent cache management with size limits
- **User experience complexity**: Mitigation - extensive user testing and feedback

### Low Risk
- **Performance with large collections**: Mitigation - pagination and lazy loading
- **Cross-platform compatibility**: Mitigation - standard web APIs and testing

## Dependencies

### External Services
- Cloudflare R2 API access and credentials
- Patreon OAuth application configuration
- n8n webhook endpoint setup and authentication
- SSL certificates for secure communication

### Internal Dependencies
- Existing token-browser.js codebase
- fa-token-browser module infrastructure
- Foundry VTT (latest version) compatibility
- User settings storage system

## Success Criteria

### Technical Success
- Authentication success rate >95%
- Token download success rate >98%
- Average token download time <5 seconds
- Zero security vulnerabilities in production

### User Experience Success
- User satisfaction score >4.5/5
- Feature adoption rate >70% among eligible subscribers
- Support ticket reduction for token management
- Seamless integration with existing workflows

## Future Enhancements

### Phase 2 Features
- Multiple cloud storage providers (AWS S3, Google Cloud)
- Team/guild shared token collections
- Token versioning and update notifications
- Advanced caching strategies (predictive pre-loading)

### Community Features
- User-generated content sharing
- Token rating and review system
- Collaborative token collections
- Integration with other Foundry VTT modules

---

## Appendices

### A. API Endpoints

#### n8n Webhook Endpoints
```
POST /webhook/patreonconnection-main
- Handles OAuth callback from Patreon
- Validates state token and processes authorization code
- Returns access token and subscription status

POST /webhook/patreon-status-change
- Handles subscription status changes from Patreon
- Updates user access permissions
- Triggers access revocation if needed
```

### B. Configuration Settings

#### Module Settings
```javascript
{
  // Existing settings
  customTokenFolder: string,
  tokenBrowserPosition: object,
  largerPreviews: boolean,
  
  // New cloud settings
  cloudEnabled: boolean,
  patreonConnected: boolean,
  accessTokenExpiry: Date,
  cacheSize: number, // MB
  autoDownloadThreshold: number, // frequently used tokens
  cloudTokensVisible: boolean
}
```

### C. Error Codes

```javascript
const ERRORS = {
  AUTH_EXPIRED: 'PATREON_AUTH_EXPIRED',
  AUTH_INVALID: 'PATREON_AUTH_INVALID',
  INSUFFICIENT_TIER: 'PATREON_INSUFFICIENT_TIER',
  NETWORK_ERROR: 'NETWORK_UNAVAILABLE',
  DOWNLOAD_FAILED: 'TOKEN_DOWNLOAD_FAILED',
  CACHE_FULL: 'LOCAL_CACHE_FULL',
  R2_ACCESS_DENIED: 'R2_ACCESS_DENIED'
};
```

### D. Testing Strategy

#### Unit Tests
- Authentication token validation
- R2 API integration functions
- Cache management operations
- Error handling scenarios

#### Integration Tests
- End-to-end OAuth flow
- Token download and caching
- Mixed local/cloud token browsing
- Webhook processing

#### User Acceptance Tests
- Patreon subscriber authentication flow
- Token browsing and usage workflows
- Error recovery scenarios
- Performance with large token collections 