# Cloud Token Storage with Patreon Authentication: Implementation Tasks

## Overview

This document outlines the implementation of cloud token functionality for the FA Token Browser module. The system integrates Patreon OAuth authentication with server-side n8n workflows to provide secure access to premium cloud-hosted tokens.

**Dependencies**: Core local token browser (✅ complete)
**Server Infrastructure**: n8n workflows for authentication and R2 storage management  
**Security Model**: All authentication validation server-side, client only stores UI display data

## 🎯 **CURRENT STATUS** (Updated)

### ✅ **COMPLETED PHASES:**
- **Phase 1**: Token Data Abstraction Layer - Complete unified system for local/cloud tokens
- **Phase 2**: File Cache System - Complete with user settings and LRU management  
- **Phase 3**: Cloud Integration - Complete with 640 tokens accessible, authentication working
- **Phase 4**: UI Integration - Complete with seamless local/cloud drag & drop

### ✅ **COMPLETED PHASES:**
- **Phase 1**: Token Data Abstraction Layer - Complete unified system for local/cloud tokens
- **Phase 2**: File Cache System - Complete with user settings and LRU management  
- **Phase 3**: Cloud Integration - Complete with 640 tokens accessible, authentication working
- **Phase 4**: UI Integration - Complete with seamless local/cloud drag & drop
- **Phase 5**: Server-Side Completion - ✅ **COMPLETED** - Signed URLs working, CORS issues resolved

### 🚧 **CURRENT PRIORITY:**
- **Code Cleanup**: Remove debug logs and simplify architecture before Phase 6

### 📋 **NEXT UP:**
- **Phase 6**: UI Polish & Visual Integration - Add cloud indicators and filters

### 🏗️ **ARCHITECTURE STATUS:**
- ✅ **Token abstraction**: Working perfectly with zero local regression
- ✅ **Authentication**: Patreon OAuth fully functional with n8n integration
- ✅ **Free tokens**: Complete workflow with CDN URLs
- ❌ **Premium tokens**: Blocked on server-side signed URL generation
- ✅ **File caching**: Ready for cloud downloads with user-configurable settings
- ✅ **Testing framework**: Comprehensive test suites for all phases

## Current File Architecture

### Existing Files (Ready for Extension)
```
├── scripts/token-browser.js          # Main UI - extend for cloud integration
├── scripts/gallery-model.js          # Data model - add cloud token support  
├── scripts/search-engine.js          # Search - extend for cloud+local unified search
├── scripts/patreon-auth-service.js   # ✅ OAuth service (implemented)
├── scripts/cloud-token-api.js        # ✅ n8n API client (basic structure)
├── templates/token-browser.hbs       # UI template - add cloud indicators
├── templates/oauth-window.hbs        # OAuth popup template
└── styles/token-browser.css          # Styles - add cloud visual indicators
```

### ✅ New Files Created
```
├── scripts/token-data-types.js       # ✅ TypeScript-style interfaces and helpers
├── scripts/local-token-service.js    # ✅ Local token operations wrapper
├── scripts/token-data-service.js     # ✅ Main abstraction layer coordinator
├── scripts/cloud-token-service.js    # ✅ Cloud API integration layer
└── scripts/token-cache-manager.js    # ✅ File caching with LRU management
```

### 🧹 Cleaned Up (Testing Files Removed)
```
├── scripts/phase1-test.js            # 🗑️ Removed - testing only
├── scripts/phase2-test.js            # 🗑️ Removed - testing only
├── scripts/phase3-test.js            # 🗑️ Removed - testing only
└── scripts/gallery-model-integration.js # 🗑️ Removed - testing only
```

### Server-side Components (n8n)
```
Authentication Endpoints:
├── /webhook/patreonconnection-foundry  # OAuth callback handler
├── /webhook/foundry-authcheck          # Polling endpoint for auth results
├── patreon-webhook-processor           # Subscription change notifications
└── user-mapping-manager                # Foundry-to-Patreon relationships

Cloud Token Endpoints:
├── /webhook/foundry-cloud-browse       # All token metadata with auth validation
├── /webhook/foundry-cloud-thumbnails   # Batch thumbnail URLs (NEW)
├── /webhook/foundry-token-download     # Signed full-resolution URLs (previews & downloads)
├── r2-api-manager                      # R2 operations with stored credentials  
└── token-access-validator              # Tier-based access control
```

## Caching Strategy Overview

⚠️ **Important**: There are TWO different types of caching - don't confuse them!

### 1. URL Cache (Phase 2.1.5) - Mixed Strategy
- **Thumbnail URLs**: CDN URLs (permanent, no expiration) - public low-res thumbnails
- **Full-resolution URLs**: Signed URLs (10 minutes) - protected full-resolution tokens
- **Where**: Browser memory/local storage
- **Purpose**: Avoid repeated API calls for same tokens
- **Size**: Tiny (just URL strings)
- **Security**: Only thumbnails are publicly cacheable, full tokens require fresh auth

### 2. File Cache (Phase 3) - Persistent, Local Storage  
- **What**: Actual downloaded image files
- **Where**: Local filesystem (user-configurable directory)
- **Duration**: Persistent until LRU eviction or manual cleanup
- **Purpose**: Store frequently used tokens locally
- **Size**: Large (actual image files, GB limits)
- **Cleared**: Manual cleanup or LRU eviction

## Implementation Tasks

### ✅ Phase 1: Token Data Abstraction Layer **COMPLETED**

#### 1.1 Unified Token Data Structure ✅
*Status: Fully implemented and tested*
- [x] Created `token-data-types.js` with TypeScript-style interfaces
- [x] Implemented `TokenData` structure supporting both local and cloud tokens
- [x] Added helper functions for token creation and validation
- [x] Created unified metadata structure with grid dimensions, file size, etc.
- [x] Implemented source detection (local vs cloud) and tier management

#### 1.2 Local Token Service Wrapper ✅
- [x] Created `local-token-service.js` wrapping existing local functionality
- [x] Implemented metadata extraction from local files
- [x] Added file existence checking and path validation
- [x] Maintained 100% backward compatibility with existing local tokens
- [x] Successfully tested with 1,862 local tokens with zero regression

#### 1.3 Token Data Service Coordinator ✅
- [x] Created `token-data-service.js` as main abstraction layer
- [x] Implemented unified APIs for both local and cloud tokens
- [x] Added service initialization and dependency management
- [x] Created comprehensive testing framework with `phase1-test.js`
- [x] Verified abstraction layer works perfectly with existing UI

> **Status**: ✅ **COMPLETED** - Token Data Abstraction Layer fully implemented and tested. Zero regression in local functionality, ready for cloud integration.

---

### ✅ Phase 2: File Cache System **COMPLETED**

#### 2.1 Token Cache Manager Implementation ✅
*Status: Fully implemented with user settings*
- [x] Created `TokenCacheManager` class for persistent file storage
- [x] Implemented user-configurable cache directory with folder picker
- [x] Added cache stored in Foundry data directory (survives module updates)
- [x] Created LRU cache with configurable size (0-5000MB) and age (0-365 days) limits
- [x] Added support for unlimited cache (0 = unlimited)
- [x] Implemented lazy initialization to avoid Foundry startup errors

#### 2.2 Cache Management & Settings ✅
- [x] Added three configurable Game Settings:
  - Token Cache Directory (with folder picker)
  - Maximum Cache Size (0-5000MB, 0=unlimited)  
  - Maximum Cache Age (0-365 days, 0=unlimited)
- [x] Integrated cache statistics and monitoring
- [x] Added cache cleanup and management methods
- [x] Created comprehensive testing with `phase2-test.js`
- [x] Verified cache system works with drag & drop workflow

> **Status**: ✅ **COMPLETED** - File Cache System fully implemented. Ready to handle cloud token downloads with proper local storage management.

---

### ✅ Phase 3: Cloud Integration **COMPLETED**

#### 3.1 Patreon Authentication Service ✅
*Status: Fully tested and working*
- [x] PatreonAuthService class with OAuth configuration
- [x] State token generation and secure handling
- [x] OAuth flow with n8n endpoints integration
- [x] Persistent authentication across Foundry sessions
- [x] Comprehensive error handling and user feedback

#### 3.2 Cloud Token Service Integration ✅
- [x] Created `cloud-token-service.js` integrating with n8n endpoints
- [x] Implemented URL management strategy:
  - Free tokens: CDN URLs (permanent)
  - Premium tokens: Signed URLs (15-min expiry, 10-min cache)
- [x] Connected cache system to actual cloud token downloads
- [x] Added comprehensive cloud token fetching and processing
- [x] Successfully tested with 640 cloud tokens

#### 3.3 Gallery Model Integration ✅
- [x] Updated `gallery-model.js` to use unified token data service
- [x] Maintained UI compatibility while adding cloud support
- [x] Implemented seamless local/cloud token mixing
- [x] Added proper error handling and graceful degradation
- [x] Created comprehensive testing with `phase3-test.js`

> **Status**: ✅ **COMPLETED** - Cloud Integration fully implemented. Authentication working, 640 cloud tokens accessible, abstraction layer complete. Ready for UI enhancements.

---

### ✅ Phase 4: UI Integration **COMPLETED**

#### 4.1 Integrate TokenDataService with UI ✅
*Status: Completed - UI fully integrated with TokenDataService, including advanced drag & drop handling for cloud tokens.*
- [x] **4.1.1** Replace getCombinedTokenManifest with TokenDataService
  - [x] Update `token-browser.js` to use `this.tokenDataService`
  - [x] Convert UI to work with TokenData objects instead of raw objects
  - [x] Maintain backward compatibility during transition
- [x] **4.1.2** Update drag & drop system to use TokenDataService
  - [x] Implement a "queued drag" system for seamless cloud token UX
  - [x] Update `TokenDragDropManager` to use TokenData objects
  - [x] Use `getFilePathForDragDrop()` method for cloud token downloads
  - [x] Ensure proper caching integration
- [x] **4.1.3** Update preview system to use TokenDataService
  - [x] Update `TokenPreviewManager` to use TokenData URLs
  - [x] Use `getThumbnailURL()` and `getFullURL()` methods
  - [x] Handle signed URL caching properly

> **Status**: ✅ **COMPLETED** - UI Integration complete. Drag & drop, previews, and main gallery view all use the unified TokenDataService, providing a seamless experience for both local and cloud tokens. The complex race conditions and UX issues with cloud token drag-and-drop have been resolved.

---

### ✅ Phase 5: Server-Side Completion **COMPLETED**

#### 5.1 Complete Missing n8n Endpoints ✅
*Status: Working - signed URLs successfully implemented*
- [x] **5.1.1** Implement `generateSignedURL` method in CloudTokenAPI ✅
  - R2 signed URL generation working for premium tokens
  - 15-minute expiry with proper security validation
  - Integration with existing n8n workflows complete
  - CORS issue resolved with fetch-based preview loading

#### 5.2 Complete CDN URL Generation ✅
*Status: Both free and premium tokens working*
- [x] **5.2.1** Implement `/webhook/foundry-token-download` endpoint ✅
  - Generate signed URLs for premium tokens working
  - Validate tier access before URL generation working
  - Return ready-to-use URLs with proper expiration working

#### 5.3 Error Handling & Reliability ✅
- [x] **5.3.1** Add comprehensive error handling ✅
  - Handle R2 API failures gracefully
  - Provide meaningful error messages to client
  - CORS caching issue resolved with separate fetch/img strategies

> **Status**: ✅ **COMPLETED** - Server-side signed URL implementation complete. Premium token access working. Both preview and drag & drop functional without CORS conflicts.

---

### 🔮 Phase 6: UI Polish & Visual Integration **FUTURE**

#### 6.1 Visual Cloud Integration
*Status: After core integration, add user-facing indicators*
- [ ] **6.1.1** Add cloud token visual indicators
  - Cloud icon overlay using CSS ::after pseudo-element
  - Different styling for free vs premium cloud tokens
  - Cache status indicators (downloaded, cached, etc.)
  - Tooltips showing token source and tier information
- [ ] **6.1.2** Create authentication status display
  - Patreon connection status in browser header
  - User tier display (Free, VIP, etc.)
  - "Connect Patreon" button when not authenticated
  - "Refresh Authentication" for expired sessions
- [ ] **6.1.3** Add token source filtering
  - Filter buttons: "All", "Local Only", "Cloud Only"
  - Update search to work seamlessly across both sources
  - Maintain filter state across browser sessions

#### 6.2 Download & Progress Management
- [ ] **6.2.1** Add download progress indicators
  - Progress bars during cloud token cache downloads
  - Download speed and time remaining estimates
  - Cancel download functionality
  - Success/error notifications
- [ ] **6.2.2** Cache management interface
  - Cache statistics display in settings
  - "Clear Cache" functionality with confirmation
  - Cache size monitoring and warnings
  - Individual token cache management

#### 6.3 Error Handling & User Experience
- [ ] **6.3.1** Comprehensive error handling
  - Graceful degradation when cloud services unavailable
  - Clear error messages for authentication issues
  - Retry mechanisms for failed operations
  - Help text for common problems
- [ ] **6.3.2** Loading states and feedback
  - Loading skeletons for cloud token fetching
  - Smooth transitions between local and cloud content
  - Performance optimizations for large libraries

> **Status**: 🔮 **FUTURE** - After core integration complete, add user-facing polish and visual integration.

---

### 🔮 Phase 7: Testing & Optimization **FUTURE**

#### 7.1 Performance Testing & Optimization
*Status: After UI completion*
  - [ ] **7.1.1** Large library performance testing
    - Test with 10,000+ cloud tokens
    - Memory usage optimization
    - Loading time benchmarks
    - Browser compatibility testing
  - [ ] **7.1.2** Cache performance optimization
    - LRU eviction efficiency testing
    - Download speed optimization
    - Storage space management validation
  - [ ] **7.1.3** Network optimization
    - Batch request optimization
    - Retry logic validation
    - Offline mode graceful degradation

#### 7.2 Security & Access Control Validation
- [ ] **7.2.1** Security audit
  - Verify no sensitive credentials in client code
  - Test server-side auth validation robustness
  - Validate access revocation scenarios
- [ ] **7.2.2** Edge case testing
  - Network failure scenarios
  - Authentication expiry handling
  - Concurrent user access patterns

> **Status**: 🔮 **FUTURE** - Comprehensive testing and optimization after core features complete.

---

### 📚 Phase 8: Documentation & Release **FINAL**

#### 8.1 User Documentation
- [ ] **8.1.1** User setup guide
  - Patreon connection instructions
  - Cache management guide
  - Troubleshooting common issues
- [ ] **8.1.2** Feature documentation
  - Cloud vs local token differences
  - Tier access explanations
  - Performance tips and best practices

#### 8.2 Release Preparation
- [ ] **8.2.1** Version management
  - Update module.json version
  - Create comprehensive changelog
  - Prepare release notes
- [ ] **8.2.2** Migration support
  - Existing user migration path
  - Settings preservation
  - Backward compatibility validation

> **Status**: 📚 **FINAL** - Documentation and release preparation after all features complete.

---

## File Modification Checklist

### Files to Modify
- [ ] `module.json` - Add new ES modules to array
- [ ] `scripts/token-browser.js` - Integrate cloud services
- [ ] `scripts/gallery-model.js` - Add cloud token support
- [ ] `scripts/search-engine.js` - Extend for unified search
- [ ] `templates/token-browser.hbs` - Add cloud UI elements
- [ ] `styles/token-browser.css` - Add cloud visual styles

### Files to Create
- [ ] `scripts/cloud-token-service.js` - Integration layer
- [ ] `scripts/token-cache-manager.js` - Local caching system
- [ ] `scripts/cloud-config.js` - Configuration management
- [ ] Unit test files for all new components

## Success Criteria

- [ ] **Authentication**: Seamless Patreon OAuth with persistent sessions
- [ ] **Cloud Integration**: Unified browsing of local and cloud tokens
- [ ] **Performance**: No degradation of local token browsing performance
- [ ] **Caching**: Efficient local caching with automatic management
- [ ] **Security**: All sensitive operations server-side validated
- [ ] **UX**: Intuitive cloud features with clear visual indicators
- [ ] **Reliability**: Graceful degradation when cloud services unavailable

## Dependencies

- **Server**: n8n workflows for authentication and token management
- **Storage**: Cloudflare R2 bucket with proper CORS configuration
- **Authentication**: Patreon OAuth application with correct redirect URLs
- **Client**: Completed local token browser (✅ done)

---

## n8n Server-Side Implementation Tasks

### Phase S1: Authentication Infrastructure (Server-Side)

#### S1.1 OAuth Callback Handler ✅
*Status: Completed - working with client Phase 1.2*
- [x] **S1.1.1** Set up `/webhook/patreonconnection-foundry` endpoint
- [x] **S1.1.2** Handle Patreon OAuth callback with authorization code
- [x] **S1.1.3** Exchange authorization code for access token via Patreon API
- [x] **S1.1.4** Extract user data (email, tier, etc.) from Patreon response
- [x] **S1.1.5** Store complete Foundry state token (crypto UUID - not parsed)
- [x] **S1.1.6** Store user mapping in database with IP validation
- [x] **S1.1.7** Log successful authentication for polling endpoint

#### S1.2 Auth Status Polling Endpoint ✅
*Status: Completed - working with client Phase 1.2*
- [x] **S1.2.1** Set up `/webhook/foundry-authcheck` endpoint
- [x] **S1.2.2** Validate incoming state token and IP match
- [x] **S1.2.3** Look up authentication result from database
- [x] **S1.2.4** Return user tier and status in simplified format
- [x] **S1.2.5** Handle expired/invalid state tokens gracefully

#### S1.3 Database Schema & User Mapping ✅
*Status: Completed - tables created and indexed*
- [x] **S1.3.1** Database schema implemented
  - `fa_data.users` - main user table (user_id, patreon_user_id, patreon_email, website_user_id, website_email)
  - `fa_data.auth_sources` - authentication sources (user_id FK, source, external_id, tier, status)
  - `fa_data.foundry_links` - foundry state mapping (user_id FK, foundry_state UUID, ip_address)
- [x] **S1.3.2** Database indexes implemented
  - Primary keys and foreign key constraints in place
  - Index on `foundry_state` for fast polling lookups
  - Index on source/external_id combinations for webhook processing
- [x] **S1.3.3** User mapping CRUD operations implemented via n8n workflow
- [x] **S1.3.4** Duplicate registration handling implemented

---

### Phase S2: Cloud Token API Infrastructure (Server-Side)

*Dependencies: Client Phase 2.1 (Cloud API Integration)*

#### S2.1 R2 Storage + CDN Integration (Core Infrastructure)
- [x] **S2.1.1** Set up Cloudflare R2 + CDN foundation ✅
  - [x] Store R2 access key, secret key, bucket name securely in n8n
  - [x] **Create custom domain for R2 bucket** (`r2-public.forgotten-adventures.net`)
  - [x] **Configure Cloudflare CDN** for the R2 bucket domain
  - [x] Set up Cache Rules: thumbnails (24h TTL), full tokens (4h TTL)
  - [x] Configure R2 bucket CORS settings for CDN access
  - [x] Test R2 connectivity through CDN (not direct R2) ✅ **VERIFIED: CF-Cache-Status: HIT, 24h cache working**
- [x] **S2.1.2** Implement CDN-aware R2 bucket scanning (Updated Structure ✅) ✅ **COMPLETED**
  - [x] **fa-public bucket**: Scan `/tokens/free_tokens/` (free full-res) ✅ **WORKING**
  - [x] **fa-tokens-bucket**: Scan `/premium_tokens/` (premium full-res only) ✅ **WORKING**
  - [x] Extract metadata: file path, size, last modified, content type, tier (free/premium) ✅ **WORKING**
  - [x] **Store PostgreSQL inventory** with CDN URLs for public content, R2 paths for premium ✅ **TABLE CREATED & POPULATED**
  - [x] **Smart URL mapping**: thumbnails + free = CDN URLs, premium = signed URL paths ✅ **LOGIC IMPLEMENTED**
  - [x] Build complete token inventory with unified metadata structure ✅ **n8n WORKFLOW COMPLETED - 640+ TOKENS SCANNED**
- [x] **S2.1.3** Implement access control using existing tier system ✅ **COMPLETED**
  - [x] Define access model (free vs premium for adventurer+ tiers) ✅ **SPEC SIMPLIFIED**
  - [x] Use existing 'tier' column in token_inventory ✅ **NO NEW SCHEMA NEEDED** 
  - [x] Use existing auth_sources tier validation ✅ **REUSE EXISTING LOGIC**
  - [x] **Updated n8n If conditions** for all qualifying tiers ✅ **IMPLEMENTED**
  - [x] Create `hasPremiumAccess()` function for tier validation ✅ **SPEC READY**
  - [x] Update browse endpoint to filter tokens by user tier ✅ **COMPLETED**
  - [x] Update download endpoint to validate access using existing tier columns ✅ **COMPLETED**
  - **📋 Implementation Guide**: `.cursor/ai-dev-tasks-main/server-side/tier-access-control-spec.md`

#### S2.2 Token Metadata Endpoint
- [x] **S2.2.1** Set up `/webhook/foundry-cloud-browse` endpoint ✅ **COMPLETED**
  - [x] Implement authentication validation ✅ **COMPLETED**
    - Validate state token exists and matches stored data
    - Check IP address matches original authentication
    - Verify subscription tier is still valid
  - [x] Implement token filtering by user tier ✅ **COMPLETED**
    - Get user's current tier from database
    - Filter complete token list to only accessible tokens
    - Return lightweight metadata (no URLs yet)
  - [x] **Built `/webhook/foundry-cloud-browse-free` for free access** ✅ **COMPLETED**
    - No authentication required for free tokens
    - Returns only tokens with `tier = 'free'`
    - Simple, fast endpoint for unauthenticated users
  - [x] Optimize response size and performance ✅ **COMPLETED**
    - Compress response data
    - Cache filtered results for repeat requests
    - Handle large token lists efficiently (~640+ tokens)
- [ ] **S2.2.2** Implement authentication validation optimization
  - [ ] Add response caching for authenticated users
  - [ ] Optimize database queries for tier validation
  - [ ] Add request rate limiting per user

#### S2.3 ~~CDN Thumbnail URL Generation Endpoint~~ (SIMPLIFIED ✅)
- [x] **S2.3.1** ~~Set up `/webhook/foundry-cloud-thumbnails` endpoint~~ **NOT NEEDED**
- [x] **S2.3.2** ~~Implement batch CDN thumbnail URL generation~~ **SIMPLIFIED**
  - **New approach**: Client-side URL construction using path transformation
  - **Formula**: `token_path` → `r2-public.forgotten-adventures.net/tokens/thumbnails/{token_path}`
  - **No server round-trip needed** - thumbnails are all public CDN URLs
  - **Ultra-fast**: Immediate URL availability, no API delays
- [ ] **S2.3.3** Configure CDN thumbnail routing
  - **CDN cache hit**: Return cached thumbnail instantly (most requests)
  - **CDN cache miss**: CDN fetches from R2, caches for 24h, serves to user
  - Point to thumbnail versions if available, fall back to full images
  - **No expiration needed** - CDN handles caching automatically
- [ ] **S2.3.4** Add batch size limits and validation  
  - Limit batch requests to 100 tokens max
  - Validate all paths exist in PostgreSQL inventory
  - Return error details for invalid/inaccessible tokens

#### S2.4 CDN Full-Resolution URL Generation Endpoint
- [ ] **S2.4.1** Set up `/webhook/foundry-token-download` endpoint (enhanced)
- [ ] **S2.4.2** Support both single and batch token requests
  - Accept single `token_path` or multiple `token_paths`
  - Maintain backward compatibility for drag & drop
  - Optimize for both preview and download use cases
- [ ] **S2.4.3** Implement secure full-resolution URL generation
  - **For previews AND downloads**: Generate short-lived signed URLs (15-min expiry)
  - **Security**: Full-resolution tokens always require authentication - no public CDN URLs
  - **Performance vs Security**: Slight performance cost for auth, but prevents token sharing
  - Include proper content-disposition headers for downloads when needed
- [ ] **S2.4.4** Add comprehensive access validation with CDN awareness
  - Validate state token and IP for each request  
  - Check tier access for each requested token path
  - **CDN security**: Validate access before returning CDN URLs
  - Log access attempts for security monitoring

---

### Phase S3: Database & Performance Optimization (Server-Side)

*Dependencies: Client Phase 3 (Local Token Caching)*

#### S3.1 Database Performance & Monitoring
- [ ] **S3.1.1** Implement database connection pooling and optimization
- [ ] **S3.1.2** Add performance monitoring and logging
  - Track endpoint response times
  - Monitor database query performance
  - Log authentication failures and suspicious activity
- [ ] **S3.1.3** Set up automated database cleanup
  - Clean expired state tokens (older than 24 hours)
  - Archive old authentication records
  - Maintain user mapping table size

#### S3.2 Database-Based Token Metadata Caching
- [ ] **S3.2.1** Implement PostgreSQL-based token inventory caching
  - Create `fa_data.token_inventory` table for all token metadata
  - Periodic R2 bucket scan (n8n workflow every few hours) to refresh inventory
  - Fast SQL queries for tier-based filtering instead of Redis
  - Leverage existing PostgreSQL infrastructure (no new services needed)
- [ ] **S3.2.2** Optimize signed URL generation
  - Cache generated URLs temporarily (5 minutes) in PostgreSQL if needed
  - Reuse URLs for identical requests within cache window
  - Monitor and optimize AWS signature generation performance

#### S3.3 Advanced CDN Optimization (Post-Launch)
*Note: Basic CDN integrated in S2.1-S2.4. These are advanced optimizations for later.*
- [ ] **S3.3.1** Smart Popular Token Caching Strategy
  - **Server-side analytics**: Track most requested tokens across all users
  - **Auto-cache top 1000 popular tokens** at CDN edge (automatic distribution)
  - **Tier-based popular caching**: Different popular sets per subscription tier
  - **Cache warming**: Pre-populate CDN with new releases
- [ ] **S3.3.2** Cost Monitoring & Alerting System
  - **Real-time cost tracking**: Monitor R2 operations and bandwidth
  - **Usage alerts**: Warn at 80% of monthly budget
  - **Per-user analytics**: Track heavy users and potential abuse
  - **Cost projection**: Predict monthly costs based on usage trends
- [ ] **S3.3.3** Advanced Caching Strategies (Optional)
  - **Cache Reserve integration**: Use Cloudflare Cache Reserve for long-term storage
  - **Multi-tier caching**: Edge → Cache Reserve → R2 hierarchy
  - **Geographic optimization**: Cache popular tokens in all edge locations
  - **Intelligent cache warming**: Predict and pre-cache likely-to-be-requested tokens

---

### Phase S4: Security & Access Control (Server-Side)

*Dependencies: Client Phase 4 (UI Integration)*

#### S4.1 Enhanced Security Validation
- [ ] **S4.1.1** Implement rate limiting on all endpoints
  - Limit authentication attempts per IP
  - Limit token requests per user/session
  - Add progressive delays for repeated failures
- [ ] **S4.1.2** Add IP whitelist/blacklist functionality
- [ ] **S4.1.3** Implement request signing validation
  - Add optional HMAC validation for sensitive requests
  - Validate request timestamps to prevent replay attacks
- [ ] **S4.1.4** Set up security monitoring and alerting
  - Monitor for suspicious access patterns
  - Alert on bulk downloads or unusual activity
  - Log all authentication and access events

#### S4.2 Subscription Management Integration
- [ ] **S4.2.1** Set up Patreon webhook handler for subscription changes
  - Handle tier upgrades/downgrades in real-time
  - Process subscription cancellations
  - Update user mapping table automatically
- [ ] **S4.2.2** Implement access revocation workflows
  - Immediately revoke access for cancelled subscriptions
  - Handle refunds and disputes
  - Provide grace periods for payment failures

---

### Phase S5: Monitoring & Deployment (Server-Side)

*Dependencies: Client Phase 5 (Integration & Testing)*

#### S5.1 Production Monitoring & Logging
- [ ] **S5.1.1** Set up comprehensive logging system
  - Log all API requests and responses
  - Track authentication events and failures
  - Monitor token access patterns
- [ ] **S5.1.2** Implement health check endpoints
  - Database connectivity check
  - R2 storage connectivity check
  - Overall system health status
- [ ] **S5.1.3** Set up alerting for critical failures
  - Database connection failures
  - R2 storage issues
  - High error rates or authentication failures

#### S5.2 Performance & Cost Optimization
- [ ] **S5.2.1** Monitor and optimize R2 costs
  - Track bandwidth usage per user/tier
  - Monitor storage costs and access patterns
  - Implement cost alerts and budgeting
- [ ] **S5.2.2** Optimize n8n workflow performance
  - Profile slow endpoints and optimize
  - Implement workflow caching where appropriate
  - Monitor and optimize database queries

---

## Client-Server Coordination Timeline

### **Phase 1**: Authentication (✅ Complete Both Sides)
- ✅ **Server**: OAuth + polling endpoints + database schema complete
- ✅ **Client**: Authentication testing complete

### **Phase 2**: API Integration with CDN-First Architecture (🚧 Current Priority)
- ✅ **Server**: S2.1 (R2 + CDN integration) complete
- ✅ **Server**: S2.1.3 (tier access control) complete  
- ✅ **Server**: S2.2.1 (token metadata endpoints) complete
- 🚧 **Server**: S2.3-S2.4 (CDN endpoints) in progress
- 🚧 **Client**: 2.1.1-2.1.7 (API client + URL caching) ready to start
- **Dependency**: Server S2.3-S2.4 (CDN endpoints) → client 2.1.2 testing
- **✅ BUILT RIGHT**: CDN architecture from day one, no rate limits or cost surprises

**Current Status**: 🚧 **CURRENT PRIORITY** - Phase 1 complete ✅, Phase 2 partially complete (S2.1.3 + S2.2.1 ✅), ready for S2.3/S2.4 or client integration