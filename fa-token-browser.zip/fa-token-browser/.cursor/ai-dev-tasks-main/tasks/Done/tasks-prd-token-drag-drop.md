# Task List: Token Browser Drag & Drop Implementation

Based on PRD: `prd-token-drag-drop.md`

## Relevant Files

- `scripts/token-browser.js` - Main Token Browser ApplicationV2 class where drag & drop functionality will be implemented
- `scripts/system-detection.js` - New utility module for game system detection and actor type mapping
- `scripts/actor-factory.js` - New module for system-aware actor creation with fallback strategies
- `templates/actor-name-dialog.hbs` - New Handlebars template for the actor name prompt dialog
- `styles/token-browser.css` - CSS updates for drag visual feedback and dialog styling
- `module.json` - Module manifest (may need updates for new script files)
- `tests/drag-drop.test.js` - Unit tests for drag & drop functionality
- `tests/system-detection.test.js` - Unit tests for system detection logic
- `tests/actor-factory.test.js` - Unit tests for actor creation logic

### Notes

- The existing `_parseTokenSize()` function in token-browser.js should be reused for token sizing logic
- Leverage Foundry VTT's native drag-drop event system and Dialog class
- Use `game.system.id` for system detection and `game.settings` for any user preferences
- Error handling should use Foundry's `ui.notifications` system for user feedback
- All drag operations should be non-destructive and provide clear user feedback

## Tasks

- [x] 1.0 System Detection and Actor Type Mapping
  - [x] 1.1 Create system detection utility that identifies current game system using `game.system.id`
  - [x] 1.2 Build actor type mapping table for major systems (dnd5e, pf2e, generic, etc.)
  - [x] 1.3 Implement fallback strategy: "npc" → "character" → minimal data structure
  - [x] 1.4 Add logging for system-specific compatibility tracking
  - [x] 1.5 Test system detection with multiple game systems

- [x] 2.0 Drag and Drop Event System
  - [x] 2.1 Add `draggable="true"` attribute to token items in TokenBrowserApp
  - [x] 2.2 Implement `dragstart` event handler with proper data transfer setup
  - [x] 2.3 Create canvas drop zone detection using `dragover` and `drop` events
  - [x] 2.4 Add visual feedback during drag operations (cursor changes, highlighting)
  - [x] 2.5 Implement coordinate transformation from screen to world coordinates
  - [x] 2.6 Add drag operation validation (only allow Token Browser → canvas drops)

- [x] 3.0 System-Aware Actor Creation Logic
  - [x] 3.1 Create actor factory function that handles system-specific actor types
  - [x] 3.2 Implement D&D 5e specific actor creation with required fields (name, type)
  - [x] 3.3 Add generic system actor creation with minimal required fields
  - [x] 3.4 Implement multi-tier fallback strategy for unsupported systems
  - [x] 3.5 Add comprehensive error handling with user-friendly notifications
  - [x] 3.6 Create token document and place on canvas with proper actor linking

- [x] 4.0 Token Sizing and Grid Integration
  - [x] 4.1 Enhance existing `_parseTokenSize()` to handle all size categories (Tiny through Gargantuan)
  - [x] 4.2 Add scale modifier parsing from filenames (e.g., "Scale150" = 1.5x scale)
  - [x] 4.3 Implement grid snapping logic for dropped tokens
  - [x] 4.4 Apply correct token dimensions to prototype token data
  - [x] 4.5 Ensure proper centering and positioning based on token size
  - [x] 4.6 Test with various token size combinations and scale modifiers

