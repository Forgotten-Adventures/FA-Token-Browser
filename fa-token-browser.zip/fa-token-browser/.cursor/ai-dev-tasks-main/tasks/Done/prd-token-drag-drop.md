# Product Requirements Document: Token Browser Drag & Drop

## Introduction/Overview

The Token Browser drag & drop feature enables users to drag token images directly from the Token Browser onto the canvas to instantly create actors with proper token assignment. This solves the current workflow friction where users must create actors separately and then manually assign tokens through Foundry's file browser interface, which is cumbersome and slow during active gameplay.

**Goal:** Streamline actor creation by providing a visual-first, drag-and-drop workflow that allows GMs to quickly populate scenes with NPCs during improvised gameplay moments.

## Goals

1. **Reduce Actor Creation Time:** Enable one-step actor creation with token assignment
2. **Improve Gameplay Flow:** Allow GMs to rapidly add visual characters during active sessions
3. **System Compatibility:** Work seamlessly across all supported Foundry VTT game systems
4. **Visual-First Workflow:** Prioritize token appearance selection over immediate stat configuration
5. **Accurate Token Sizing:** Automatically apply correct grid size and scale based on filename conventions

## User Stories

1. **As a GM during active gameplay**, I want to drag a goblin token from the browser onto the canvas so that I can instantly add an NPC to combat without breaking session flow.

2. **As a GM preparing a scene**, I want to drag multiple tokens onto the canvas so that I can quickly populate an encounter with properly sized and positioned creatures.

3. **As a player setting up my character**, I want to drag my character art onto the canvas so that I can create my character sheet with the correct token already assigned.

4. **As a GM using different game systems**, I want the drag-drop feature to work consistently so that I don't need to learn different workflows for each system.

5. **As a user with large tokens**, I want the system to automatically size my Huge dragon token to 3x3 grid squares so that it appears correctly without manual adjustment.

## Functional Requirements

1. **FR-1:** The system must detect drag start events on token items in the Token Browser
2. **FR-2:** The system must provide visual feedback during drag operations (cursor change, token highlighting)
3. **FR-3:** The system must detect valid drop zones on the canvas
4. **FR-4:** The system must prompt the user for an actor name with a smart default derived from the filename
5. **FR-5:** The system must detect the current game system and create appropriate actor types (e.g., "npc" for D&D 5e, "character" for generic systems)
6. **FR-6:** The system must handle system-specific actor requirements (e.g., D&D 5e requires name and type fields)
7. **FR-7:** The system must parse token size from filename conventions (Tiny, Small, Medium, Large, Huge, Gargantuan)
8. **FR-8:** The system must parse scale modifiers from filenames (e.g., "Scale150" = 1.5x scale)
9. **FR-9:** The system must apply correct token dimensions to the created actor's prototype token
10. **FR-10:** The system must snap token placement to the grid
11. **FR-11:** The system must place the created token on the canvas at the drop coordinates
12. **FR-12:** The system must assign the dragged image as both the actor image and token texture
13. **FR-13:** The system must provide user feedback for successful actor creation
14. **FR-14:** The system must handle drag operations only from Token Browser to canvas (ignore other drag targets)
15. **FR-15:** The system must prevent invalid drag operations with appropriate feedback

## Non-Goals (Out of Scope)

1. **Asset/Tile drag-and-drop:** Only actor creation, not scene decoration
2. **Advanced actor configuration:** Initial implementation focuses on basic actor shell with token
3. **Bulk operations:** Single token drag only, not multi-select
4. **Custom drop zones:** Only canvas drops supported initially
5. **Token animation:** Static token placement only
6. **Cloud/remote token integration:** Local token libraries only for initial version

## Design Considerations

- **Visual Feedback:** Use existing Foundry VTT drag-drop conventions (grab cursor, semi-transparent drag preview)
- **Dialog Design:** Follow Foundry's standard dialog patterns for actor name prompt
- **Grid Integration:** Leverage existing grid snapping and sizing logic from the hover preview system
- **Error States:** Use Foundry's notification system for user feedback
- **Responsive Design:** Ensure drag operations work on both desktop and touch devices

## Technical Considerations

- **System Detection:** Use `game.system.id` to determine current game system
- **Actor Type Mapping:** Maintain a lookup table for system-specific actor types and required fields
- **Fallback Strategy:** Implement graceful degradation for unsupported systems
- **Token Sizing Logic:** Reuse existing `_parseTokenSize()` function from hover preview implementation
- **Canvas Integration:** Hook into Foundry's existing drag-drop event system
- **Performance:** Ensure drag operations don't impact large token library performance

## Success Metrics

1. **Workflow Efficiency:** Reduce actor-with-token creation time from ~30 seconds to ~5 seconds
2. **User Adoption:** Track usage of drag-drop vs traditional actor creation methods
3. **Error Rate:** Maintain <5% failure rate for actor creation across supported systems
4. **System Coverage:** Successfully support 90%+ of active game systems in Foundry ecosystem
5. **User Feedback:** Achieve positive user sentiment for workflow improvement

## System-Specific Requirements

### D&D 5e
- Actor type: "npc" (default) or "character" for players
- Required fields: name, type
- Optional: Set appropriate creature type based on token name parsing

### Generic Systems
- Actor type: "character" (most common fallback)
- Required fields: name only
- Graceful handling of missing actor type support

### Fallback Strategy
- Attempt common actor types in order: "npc" → "character" → minimal data structure
- Log system-specific errors for future compatibility improvements

## Open Questions

1. Should the system attempt to parse creature types from filenames for stat block pre-population?
2. Should players be restricted from drag-drop actor creation in certain systems?
3. Should the system remember user preferences for actor types per system?
4. How should the system handle tokens with non-standard size naming conventions?

## Implementation Priority

**Phase 1 (MVP):**
- Core drag-drop mechanics
- System detection and basic actor creation
- Grid snapping and token sizing
- D&D 5e and generic system support

**Phase 2 (Enhancement):**
- Extended system support
- Advanced error handling
- User preference storage
- Performance optimizations 