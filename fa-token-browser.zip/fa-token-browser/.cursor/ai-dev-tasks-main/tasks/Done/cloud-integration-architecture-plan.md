# Cloud Integration Architecture Plan
## Addressing Local vs Cloud Token Data Layer Challenges

### Problem Statement

The current FA Token Browser is built around **local file system access**:
- **Previews**: Read local files directly via `img.src = path`
- **Drag & Drop**: Use local file paths in drag data
- **Metadata**: Extract file size via `fetch(url, {method: 'HEAD'})`
- **Canvas Creation**: Find existing `<img>` elements by `src` matching

But **cloud tokens** work fundamentally differently:
- **Thumbnails**: CDN URLs (public, permanent) - `r2-public.forgotten-adventures.net/tokens/thumbnails/...`
- **Free Full-Resolution**: CDN URLs (public, permanent) - `r2-public.forgotten-adventures.net/tokens/free_tokens/...`
- **Premium Full-Resolution**: Signed URLs (private, 15-min expiry) - from private R2 bucket
- **Metadata**: From R2 database, not file system
- **Caching**: Need persistent file downloads, not just URLs

**Without proper architecture, we'll have incompatible systems bolted together.**

---

## Core Architectural Solution: Token Data Abstraction Layer

### 1. Unified Token Data Structure

Create a **TokenData interface** that works for both local and cloud:

```javascript
// Unified Token Data Structure
const tokenData = {
  // Core Identity
  filename: "dragon_large.png",
  path: "creatures/dragon_large.png",  // Virtual path (local: actual, cloud: R2 path)
  source: "local" | "cloud",
  
  // URLs for Different Uses
  urls: {
    thumbnail: "...",        // Thumbnail/grid display (local: same as full, cloud: CDN thumbnails)
    full: "...",             // Full-resolution for both previews AND drag&drop (local: file path, cloud: CDN for free, signed for premium)
  },
  
  // Metadata (from different sources)
  metadata: {
    fileSize: 245760,       // In bytes (from R2 database for cloud, file system for local)
    gridWidth: 2,           // Grid squares (parsed from filename)
    gridHeight: 2,          // Grid squares (parsed from filename)
    scale: 1.0,             // Scale modifier (parsed from filename)
    lastModified: Date,     // From R2 database or file system
    // Note: Image pixel dimensions (width/height) are NOT available from R2 database
    // These would need to be extracted from actual image files if needed
  },
  
  // Cloud-specific
  tier: "free" | "premium" | null,
  
  // Cache status (for cloud tokens)
  cache: {
    isDownloaded: false,     // Is full file cached locally?
    localPath: null,         // Path to cached file if downloaded
    downloadedAt: null,      // When was it cached?
    lastAccessed: null,      // For LRU eviction
  }
};
```

### 2. Token Data Service Layer

Create **services** that provide consistent APIs regardless of source:

```javascript
// scripts/token-data-service.js
export class TokenDataService {
  constructor() {
    this.localService = new LocalTokenService();
    this.cloudService = new CloudTokenService();
    this.cacheManager = new TokenCacheManager();
  }
  
  // Unified methods that work for both local and cloud
  async getTokenData(source, path) { /* ... */ }
  async getThumbnailURL(tokenData) { /* ... */ }
  async getFullURL(tokenData) { /* Single method for both previews AND drag&drop */ }
  async getTokenMetadata(tokenData) { /* ... */ }
}
```

### 3. Preview System Abstraction

Modify **TokenPreviewManager** to work with TokenData objects:

```javascript
// OLD WAY (local files only)
_showHoverPreview(img, tokenItem) {
  const path = tokenItem.getAttribute('data-path');
  const filename = tokenItem.getAttribute('data-filename');
  
  this._previewImg.src = img.src; // PROBLEM: Cloud needs signed URLs
  this._tryGetFileSize(img.src);   // PROBLEM: Cloud has metadata from database
}

// NEW WAY (unified)
async _showHoverPreview(img, tokenItem) {
  const tokenData = this._getTokenDataFromElement(tokenItem);
  
  const fullURL = await this.tokenDataService.getFullURL(tokenData);
  this._previewImg.src = fullURL;
  
  const metadata = await this.tokenDataService.getTokenMetadata(tokenData);
  // Note: For cloud tokens, img.naturalWidth/Height will be available after image loads
  // Grid dimensions come from filename parsing, not database
  this._updatePreviewDimensions(img.naturalWidth, img.naturalHeight, metadata.gridWidth, metadata.gridHeight, metadata.scale, metadata.fileSize);
}
```

### 4. Drag & Drop System Abstraction

Modify **TokenDragDropManager** to handle URLs properly:

```javascript
// OLD WAY (local paths)
_onDragStart(event) {
  const path = tokenItem.getAttribute('data-path');
  const fullUrl = tokenItem.getAttribute('data-full-url') || path;
  
  // Used both for preview AND final token creation
  dragData.url = fullUrl;  // PROBLEM: Cloud needs signed URLs with expiry
}

// NEW WAY (reuse same URL from preview)
async _onDragStart(event) {
  const tokenData = this._getTokenDataFromElement(tokenItem);
  
  // Reuse the same full URL - no need for separate drag URL!
  const fullURL = await this.tokenDataService.getFullURL(tokenData);
  
  dragData.url = fullURL;
  dragData.tokenData = tokenData; // Pass full metadata
}
```

---

## Phase-by-Phase Implementation Strategy

### Phase 1: Create Abstraction Layer (Foundation)
**Goal**: Create the unified data structures without breaking existing functionality

1. **Create TokenData interfaces** and service classes
2. **Wrap existing local token logic** in the new services
3. **Update gallery-model.js** to return TokenData objects instead of raw objects
4. **Verify local tokens still work** exactly as before

**Success Criteria**: Zero regression in local token functionality

### Phase 2: Implement File Cache System
**Goal**: Create the bridge between cloud URLs and local file access FOR DRAG & DROP ONLY

This is **critical** because:
- **Drag canvas creation** looks for loaded images in the DOM
- **File downloads** should only happen when user actually drags (not for previews)

```javascript
// scripts/token-cache-manager.js
export class TokenCacheManager {
  async downloadToken(tokenData, sourceURL) {
    // Download from cloud URL to local cache directory
    // REQUIRED for drag & drop - Foundry actors need file paths
    const localPath = await this.downloadFromURL(sourceURL, tokenData.filename);
    
    // Update cache metadata
    tokenData.cache.isDownloaded = true;
    tokenData.cache.localPath = localPath;
    tokenData.cache.downloadedAt = Date.now();
    tokenData.cache.lastAccessed = Date.now();
    
    return localPath; // Return file path for Foundry
  }
  
  async getCachedPath(tokenData) {
    if (tokenData.cache.isDownloaded && this.fileExists(tokenData.cache.localPath)) {
      tokenData.cache.lastAccessed = Date.now(); // Update LRU
      return tokenData.cache.localPath;
    }
    return null; // Not cached or file missing
  }
  
  async ensureTokenDownloaded(tokenData, sourceURL) {
    // Check cache first, download if needed
    const cachedPath = await this.getCachedPath(tokenData);
    if (cachedPath) {
      return cachedPath; // Already downloaded
    }
    
    // Not cached - download now (required for Foundry)
    return await this.downloadToken(tokenData, sourceURL);
  }
}
```

**Preview Logic (No File Downloads)**:
```javascript
async getFullURL(tokenData) {
  if (tokenData.source === 'local') {
    return tokenData.path; // Local file path
  }
  
  // Cloud token - NEVER download for previews, use URLs directly
  if (tokenData.tier === 'free') {
    return tokenData.urls.full; // CDN URL (permanent for free tokens)
  } else {
    // Premium: Get/cache signed URL for 10 minutes (covers preview→drag workflow)
    return await this.cloudService.getSignedURL(tokenData); // Signed URL cached in memory
  }
}
```

**Drag & Drop Logic (REQUIRED File Download)**:
```javascript
async getDragDownloadURL(tokenData) {
  if (tokenData.source === 'local') {
    return tokenData.path; // Local file path
  }
  
  // Cloud token - MUST download for Foundry actors to work
  if (tokenData.cache.isDownloaded) {
    return tokenData.cache.localPath; // Use existing cached file
  }
  
  // Not cached - download NOW (Foundry needs actual file paths)
  const sourceURL = await this.getFullURL(tokenData); // Reuse cached signed URL
  const localPath = await this.cacheManager.downloadToken(tokenData, sourceURL);
  
  return localPath; // Return local file path for Foundry
}
```

### Phase 3: Integrate Cloud Token Services
**Goal**: Add cloud token support while maintaining existing preview/drag systems

1. **Update TokenDataService** to handle cloud tokens
2. **Implement signed URL management** with caching
3. **Update preview and drag systems** to use the abstraction layer
4. **Add cloud-specific UI indicators**

### Phase 4: Optimize and Polish
**Goal**: Performance, caching, and user experience optimizations

---

## Critical Design Decisions

### 1. Simplified URL Strategy: "Free = Permanent, Premium = Signed"

**Key Insight**: Free and premium tokens have fundamentally different URL patterns:

```javascript
// URL Generation Logic
function getCloudTokenURL(tokenData, useCase) {
  if (useCase === 'thumbnail') {
    // All thumbnails are public CDN
    return `https://r2-public.forgotten-adventures.net/tokens/thumbnails/${tokenData.path}`;
  }
  
  if (tokenData.tier === 'free') {
    // Free full-resolution tokens are public CDN (permanent)
    return `https://r2-public.forgotten-adventures.net/tokens/free_tokens/${tokenData.path}`;
  } else {
    // Premium tokens require signed URLs (15-min expiry)
    // IMPORTANT: Cache this URL so preview + drag&drop use the same URL!
    return await getSignedURL(tokenData.path); // From private R2 bucket
  }
}
```

**Benefits**:
- ✅ **Free tokens**: No expiry, no URL caching needed, work like local files
- ✅ **Premium tokens**: Only these need complex signed URL management  
- ✅ **Simplified logic**: Tier-based branching instead of universal signed URLs
- ✅ **Better performance**: Free tokens have zero URL management overhead
- ✅ **URL Reuse**: Same full URL for both preview AND drag&drop (less server requests!)
- ✅ **Smart Caching**: Premium URLs cached for 10 minutes, covers preview→drag workflow

### 2. Cache Strategy: "URLs for Previews, Files for Drag & Drop"

**Problem**: Don't want to download files just for previews, but Foundry actors REQUIRE file paths
**Solution**: Two-tier caching strategy

**Tier 1 - URL Cache (In-Memory)**: For previews and URL reuse
**Tier 2 - File Cache (Required for Drag)**: Download on drag & drop (Foundry compatibility)

```javascript
// Tier 1: URL Cache (In-Memory) - Fast, lightweight
class URLCache {
  constructor() {
    this.signedURLCache = new Map(); // Premium signed URLs (10-min expiry)
  }
  
  async getURL(tokenData, useCase) {
    if (tokenData.source === 'local') {
      return tokenData.path; // Direct file access
    }
    
    switch (useCase) {
      case 'thumbnail':
        return tokenData.urls.thumbnail; // CDN URL (permanent)
      case 'preview':
      case 'drag':
        if (tokenData.tier === 'free') {
          return tokenData.urls.full; // CDN URL (permanent)
        } else {
          return await this.getCachedSignedURL(tokenData); // Cached signed URL
        }
    }
  }
}

// Tier 2: File Cache (REQUIRED) - Download on drag & drop for Foundry compatibility
class FileCache {
  async downloadForDrag(tokenData, sourceURL) {
    // ALWAYS download when user drags - Foundry actors need file paths
    const localPath = await this.downloadAndCache(tokenData, sourceURL);
    
    // Update token data cache status
    tokenData.cache.isDownloaded = true;
    tokenData.cache.localPath = localPath;
    tokenData.cache.downloadedAt = Date.now();
    tokenData.cache.lastAccessed = Date.now();
    
    return localPath; // Foundry needs actual file path, not URL
  }
}
```

### 3. Metadata Strategy: "Filename Parsing + Database + DOM"

**Available Metadata Sources**:
- **R2 Database**: File size, last modified (what we have)
- **Filename Parsing**: Grid size, scale (existing `parseTokenSize()` function)  
- **DOM Image**: Pixel dimensions (after image loads in browser)

**Solution**: Hybrid approach using all sources

```javascript
async getTokenMetadata(tokenData) {
  if (tokenData.source === 'cloud') {
    // Cloud tokens: Combine database + filename parsing
    const parsed = parseTokenSize(tokenData.filename);
    return {
      fileSize: tokenData.metadata.fileSize,        // From R2 database
      lastModified: tokenData.metadata.lastModified, // From R2 database
      gridWidth: parsed.gridWidth,                   // From filename parsing
      gridHeight: parsed.gridHeight,                 // From filename parsing  
      scale: parsed.scale,                          // From filename parsing
      // Pixel dimensions: Available from DOM after image loads (img.naturalWidth/Height)
      // Used for: 1) Preview tooltip display, 2) Grid overlay calculations
    };
  } else {
    // Extract from local file (existing logic)
    return await this.extractLocalMetadata(tokenData.path);
  }
}
```

**How Pixel Dimensions Are Actually Used:**

1. **Preview Tooltip Display**: `"1024×768px (2×2 grid at 1.5x scale) - 245KB"`
   ```javascript
   _updatePreviewDimensions(img.naturalWidth, img.naturalHeight, gridWidth, gridHeight, scale, fileSize)
   ```

2. **Grid Overlay Calculations**: Visual grid lines overlaid on preview images
   ```javascript
   buildGridCSS(sizeInfo, rect.width, rect.height) // Uses actual rendered image size
   ```

3. **All Functional Calculations**: Based on grid dimensions, not pixels
   ```javascript
   calcDragPreviewPixelDims({gridWidth, gridHeight, scale}, gridSize, zoom)
   // Result: gridWidth × gridSize × scale × zoom (no actual image pixels involved)
   ```

**Key Insights**: 
- ✅ **Pixel dimensions ARE used but only for display** - preview tooltip shows "1024×768px (2×2 grid)" 
- ✅ **Grid overlay calculations need actual image size** - `buildGridCSS()` uses `imgWidth/imgHeight` from DOM
- ✅ **All calculations are grid-based** - drag preview size calculated from `gridWidth × gridSize × scale × zoom`
- ✅ **Browser provides pixel dimensions** - `img.naturalWidth/Height` available after image loads
- ✅ **Filename parsing is core** - `parseTokenSize()` extracts `gridWidth`, `gridHeight`, `scale` from filename
- ✅ **R2 database provides what we can't parse** - file size and last modified date

### 4. URL Expiry Management: "10-Minute Cache Window for Premium Only"

**Problem**: Premium token signed URLs expire in 15 minutes but we need them for previews AND drag operations  
**Solution**: Cache signed URLs for 10 minutes (5-minute safety buffer), free tokens use permanent CDN URLs

```javascript
// URL cache (in memory, not file cache)
this.signedURLCache = new Map();

async getSignedURL(tokenData) {
  // Only premium tokens need signed URLs
  if (tokenData.tier === 'free') {
    return tokenData.urls.full; // Use permanent CDN URL
  }
  
  const cacheKey = tokenData.path;
  const cached = this.signedURLCache.get(cacheKey);
  
  if (cached && Date.now() - cached.timestamp < 10 * 60 * 1000) {
    return cached.url; // Still valid
  }
  
  // Get fresh signed URL for premium token
  const newURL = await this.cloudAPI.getSignedURL(tokenData.path);
  this.signedURLCache.set(cacheKey, {
    url: newURL,
    timestamp: Date.now()
  });
  
  return newURL;
}
```

---

## Implementation Order (No "Winging It")

### Must Complete in Order:

1. **Phase 1**: Abstraction layer with zero regression
2. **Phase 2**: File cache system (critical bridge)
3. **Phase 3**: Cloud integration using the bridges
4. **Phase 4**: Optimization and polish

### Cannot Skip:
- **Token data abstraction** - without this, we'll have two incompatible systems
- **File cache implementation** - without this, previews and drag won't work properly
- **URL management system** - without this, signed URLs will break unexpectedly

### Validation at Each Phase:
- **Phase 1**: All local functionality identical to current
- **Phase 2**: Cache downloads work, cached tokens act like local files
- **Phase 3**: Cloud tokens display, preview, and drag correctly
- **Phase 4**: Performance meets requirements, UI is polished

---

## File Architecture Changes

### New Files Needed:
```
scripts/
├── token-data-service.js      # Main abstraction layer
├── local-token-service.js     # Local file operations  
├── cloud-token-service.js     # Cloud API + signed URL management
├── token-cache-manager.js     # File download and cache management
└── token-data-types.js        # TypeScript-style interfaces
```

### Modified Files:
```
scripts/
├── gallery-model.js           # Return TokenData objects
├── token-preview-manager.js   # Use TokenDataService
├── token-dragdrop-manager.js  # Use TokenDataService  
├── lazy-loading-manager.js    # Handle TokenData objects
└── token-browser.js           # Orchestrate new services
```

---

## Typical User Workflow

### **Scenario 1: User Browses 50 Premium Tokens Quickly** 🔍
1. **Hover over token** → Get signed URL (cached for 10 minutes)
2. **Preview displays** → Uses cached signed URL (no download)
3. **Move to next token** → Previous URL stays cached
4. **Repeat 50 times** → Only URLs cached, **zero file downloads**
5. **Result**: Fast browsing, no disk space used

### **Scenario 2: User Drags Premium Token After Preview** 🖱️
1. **Hover over token** → Get signed URL (cached)
2. **Preview displays** → Uses cached signed URL  
3. **User drags token** → **Download file using cached URL** (no new server request for URL!)
4. **Token created** → Uses local file path (Foundry requirement)
5. **Result**: URL reused, file downloaded only when actually needed

### **Scenario 3: User Drags Same Token Again** 💾
1. **First drag** → Download file to cache
2. **Second drag of same token** → Use cached file (instant!)
3. **Token created** → Uses existing local file path
4. **Result**: No re-download, instant token creation

---

## Key Architectural Improvements

### **1. URL Efficiency** ⚡
- **Single URL per token**: Same full URL for preview AND drag&drop
- **Smart caching**: Premium URLs cached for 10 minutes (covers typical user workflow)
- **No redundant requests**: Hover preview → drag operation uses cached URL
- **Free token advantage**: Permanent CDN URLs, zero expiry management

### **2. Metadata Strategy** 🎯  
- **Hybrid approach**: Database (file size) + filename parsing (grid size) + DOM (pixel dimensions)
- **Perfect timing**: Metadata available exactly when needed (after image loads)
- **Reuse existing logic**: `parseTokenSize()` works for both local and cloud tokens
- **No over-engineering**: Don't extract pixel dimensions we get from browser anyway

### **3. Smart Cache Architecture** 🗄️
- **URL cache**: In-memory cache for premium signed URLs (10-minute window)
- **No preview downloads**: Browsing 50 tokens quickly won't fill user's disk
- **Drag-triggered downloads**: File cache REQUIRED when user drags (Foundry needs file paths)
- **URL reuse**: Preview→drag workflow uses same cached signed URL (no double server requests)
- **Persistent cache**: Downloaded files persist for repeated use (LRU cleanup)

---

**This architecture ensures**:
- ✅ No "patching" - proper abstraction from day one
- ✅ Both local and cloud tokens work with existing preview/drag systems
- ✅ File cache bridges the gap between URLs and file system expectations
- ✅ Graceful degradation when cloud services are unavailable
- ✅ Performance optimization through proper caching strategies
- ✅ **Minimal server requests** - URL reuse and smart caching
- ✅ **Simplified metadata** - use what we have, get what we need from browser

**Ready to proceed with Phase 1 implementation?** 