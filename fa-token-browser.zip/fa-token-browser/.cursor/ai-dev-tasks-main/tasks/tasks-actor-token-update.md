# Task List: Actor Token Update via Drag & Drop

Based on existing drag & drop functionality, extend to support dropping tokens onto existing actors in the actors panel to update their prototype token.

## Overview

The FA Token Browser already has a complete drag & drop system that handles canvas drops, including all cloud/local token management, downloading, caching, and URL resolution. This task simply extends the **drop target detection** to also support dropping onto actors in the sidebar, with a different action (update prototype token instead of create new actor).

**Goal**: Reuse the existing drag & drop infrastructure to enable updating actor prototype tokens by simply changing the drop target and action, with confirmation prompts to prevent accidental changes.

**Key Insight**: All the complex token handling (cloud downloads, caching, URL management) is already done - we just need new drop target detection and a different drop handler.

## Relevant Files

- `scripts/token-dragdrop-manager.js` - Extend existing drag & drop logic to handle actor drops
- `scripts/actor-factory.js` - Add prototype token update functions
- `scripts/token-browser.js` - Integration point for new drop targets
- `templates/token-update-confirm.hbs` - New confirmation dialog template
- `styles/token-browser.css` - Visual feedback for actor drop zones
- `module.json` - Update for any new script files

## User Stories

1. **As a GM preparing for a session**, I want to drag a new token onto an existing actor so I can quickly update their appearance without opening the actor sheet.

2. **As a GM during gameplay**, I want to update an NPC's token to reflect a transformation or status change by simply dragging the new token onto the actor.

3. **As a user making bulk updates**, I want a confirmation prompt when dropping tokens onto actors so I can avoid accidental changes.

4. **As a GM with many actors**, I want clear visual feedback when hovering over valid drop targets so I know where I can drop tokens.

## Tasks

### 1.0 Extend Drop Target Detection *(Reuse Existing Drag System)*
- [ ] **1.1** Add actors sidebar to existing drop target detection
  - [ ] 1.1.1 Identify actors sidebar DOM elements (`.actors-sidebar .directory-item`)
  - [ ] 1.1.2 Extend existing `dragover`/`dragenter` logic to include actor entries
  - [ ] 1.1.3 Reuse existing drag validation (Token Browser source check)
  - [ ] 1.1.4 Add actor-specific visual feedback CSS classes

- [ ] **1.2** Implement actor drop zone visual feedback
  - [ ] 1.2.1 Add CSS for `.actor-drop-target` highlighting 
  - [ ] 1.2.2 Show visual indicator when hovering over valid actor targets
  - [ ] 1.2.3 Reuse existing cursor change logic from canvas drops
  - [ ] 1.2.4 Handle actor folders (drop on individual actors only)

### 2.0 Actor Drop Handler *(New Drop Action, Reuse Token Processing)*
- [ ] **2.1** Add actor drop processing to existing drop handler
  - [ ] 2.1.1 Detect drop target type: canvas vs actor sidebar
  - [ ] 2.1.2 Route to existing canvas logic OR new actor update logic
  - [ ] 2.1.3 Extract actor ID from dropped target element
  - [ ] 2.1.4 Validate actor exists and user has modify permissions

- [ ] **2.2** Reuse existing token data processing
  - [ ] 2.2.1 **REUSE**: Existing token data extraction from drag event
  - [ ] 2.2.2 **REUSE**: Cloud/local token handling and caching logic
  - [ ] 2.2.3 **REUSE**: Token downloading and URL resolution
  - [ ] 2.2.4 **REUSE**: Token size parsing from filename

### 3.0 Confirmation Dialog System
- [ ] **3.1** Create token update confirmation dialog
  - [ ] 3.1.1 Design confirmation dialog template with current vs new token preview
  - [ ] 3.1.2 Show actor name, current token, and proposed new token
  - [ ] 3.1.3 Include options for updating actor image vs token only
  - [ ] 3.1.4 Add "Don't ask again" checkbox for power users

- [ ] **3.2** Implement dialog state management
  - [ ] 3.2.1 Create dialog class extending Foundry's Dialog base class
  - [ ] 3.2.2 Handle confirm/cancel/close actions appropriately
  - [ ] 3.2.3 Remember user preferences for confirmation behavior
  - [ ] 3.2.4 Support keyboard shortcuts (Enter to confirm, Escape to cancel)

- [ ] **3.3** Add preview functionality to confirmation dialog
  - [ ] 3.3.1 Show side-by-side current token vs new token comparison
  - [ ] 3.3.2 Display token size and scale information changes
  - [ ] 3.3.3 Show estimated grid size difference if applicable
  - [ ] 3.3.4 Include file size and source information (local vs cloud)

### 4.0 Prototype Token Update Logic *(New Function, Reuse Token Parsing)*
- [ ] **4.1** Create prototype token update function
  - [ ] 4.1.1 Add `updateActorPrototypeToken()` to actor-factory.js
  - [ ] 4.1.2 **REUSE**: Token size parsing from existing `_parseTokenSize()` logic
  - [ ] 4.1.3 Update prototype token texture with final cached/local path
  - [ ] 4.1.4 Apply grid dimensions and scale from parsed token data
  - [ ] 4.1.5 Preserve existing prototype token settings (vision, light, etc.)

- [ ] **4.2** Handle actor image vs token texture options
  - [ ] 4.2.1 Update prototype token texture (always)
  - [ ] 4.2.2 Optionally update actor portrait image (user choice in dialog)
  - [ ] 4.2.3 Handle cases where actor has no current prototype token
  - [ ] 4.2.4 Preserve non-visual token settings (vision, light, etc.)

### 5.0 Cloud Token Integration *(Already Handled by Existing System)*
- [ ] **5.1** Verify cloud token support works automatically
  - [ ] 5.1.1 **VERIFY**: Cloud tokens get downloaded/cached by existing system
  - [ ] 5.1.2 **VERIFY**: Final local path is available for prototype update
  - [ ] 5.1.3 **VERIFY**: Signed URL handling works for prototype updates
  - [ ] 5.1.4 **VERIFY**: No additional cloud-specific logic needed

- [ ] **5.2** Test cloud token edge cases
  - [ ] 5.2.1 Test free cloud tokens (permanent CDN URLs)
  - [ ] 5.2.2 Test premium cloud tokens (signed URLs + caching)
  - [ ] 5.2.3 Test mixed local/cloud tokens in confirmation dialog
  - [ ] 5.2.4 Test network failure scenarios (should gracefully fail)

### 6.0 Simple Error Handling *(Reuse Existing Patterns)*
- [ ] **6.1** Add actor-specific error handling
  - [ ] 6.1.1 Handle actor update permission errors (reuse existing permission checks)
  - [ ] 6.1.2 **REUSE**: Token file access errors (already handled by existing system)
  - [ ] 6.1.3 Show success/error notifications using existing notification system
  - [ ] 6.1.4 **REUSE**: Token download/cache errors (already handled)

### 7.0 Basic Settings Integration *(Minimal New Settings)*
- [ ] **7.1** Add minimal actor update settings
  - [ ] 7.1.1 Setting to enable/disable actor drop functionality
  - [ ] 7.1.2 Setting to enable/disable confirmation dialogs
  - [ ] 7.1.3 Choice to update actor portrait along with token by default
  - [ ] 7.1.4 **REUSE**: All existing drag & drop settings apply automatically

### 8.0 Testing *(Focus on New Drop Target Only)*
- [ ] **8.1** Test new drop target functionality
  - [ ] 8.1.1 Test actor sidebar drop detection
  - [ ] 8.1.2 Test confirmation dialog workflow
  - [ ] 8.1.3 Test prototype token updates
  - [ ] 8.1.4 **VERIFY**: Canvas drops still work (no regression)

- [ ] **8.2** Test cloud/local token integration
  - [ ] 8.2.1 **VERIFY**: Local tokens work for actor updates
  - [ ] 8.2.2 **VERIFY**: Cloud tokens work for actor updates
  - [ ] 8.2.3 **VERIFY**: Token caching works for actor updates
  - [ ] 8.2.4 **VERIFY**: No additional cloud logic needed

## Success Criteria

- [ ] **Functionality**: Users can drag tokens from Token Browser onto actors in sidebar to update prototype tokens
- [ ] **Safety**: Confirmation dialog prevents accidental changes with clear preview
- [ ] **Integration**: Works seamlessly with existing canvas drag & drop without conflicts
- [ ] **Performance**: No noticeable performance impact on large actor directories
- [ ] **Compatibility**: Functions across different game systems and Foundry themes
- [ ] **Error Handling**: Graceful failure with clear user feedback and recovery options
- [ ] **Cloud Support**: Cloud tokens work correctly for prototype updates with proper caching

## Dependencies

- **Existing drag & drop system**: Canvas drop functionality must remain functional
- **Actor-factory.js**: Extend existing actor creation logic for prototype updates
- **Cloud token system**: Integration with existing cloud token caching and authentication
- **Foundry VTT API**: Actor update permissions and prototype token API access

## Risk Considerations

- **Performance**: Large actor directories might impact drag responsiveness
- **Permissions**: Complex actor ownership scenarios in multiplayer games
- **Token persistence**: Cloud tokens used as prototypes need reliable URL management
- **UI conflicts**: Avoid interfering with Foundry's native actor directory functionality
- **Data integrity**: Ensure prototype updates don't corrupt actor data

## Future Enhancements

- **Batch updates**: Select multiple actors and update all with same token
- **Token variants**: Quick switching between multiple token options for same actor
- **Integration with actor sheets**: Direct drag & drop onto open actor sheets
- **History tracking**: Maintain history of prototype token changes for actors 